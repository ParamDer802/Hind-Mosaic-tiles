import React from 'react';
import SectionTitle from '../components/ui/SectionTitle';

const About: React.FC = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 bg-neutral-900">
        <div className="container-custom text-center text-white py-20">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">About Us</h1>
          <p className="text-xl max-w-2xl mx-auto">Learn about our journey, mission, and commitment to quality</p>
        </div>
      </section>

      {/* Company Overview */}
      <section className="section">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-neutral-700 mb-4">
                Founded in 2005, Hind Mosaic Tiles has grown from a small workshop to one of Gujarat's renowned manufacturers of quality mosaic tiles, paver blocks, and parking tiles.
              </p>
              <p className="text-neutral-700 mb-4">
                Based in Upleta, we combine traditional craftsmanship with modern manufacturing techniques to create durable and aesthetically pleasing products for both residential and commercial applications.
              </p>
              <p className="text-neutral-700">
                Over the years, we have built a reputation for reliability, quality, and exceptional customer service. Our products are used across India in various projects, from residential homes to commercial complexes and public spaces.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/5582957/pexels-photo-5582957.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Our Factory"
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section bg-neutral-50">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="mb-4">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary-50 mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ff7342" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="m9 12 2 2 4-4"></path>
                  </svg>
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-neutral-700">
                To manufacture and deliver high-quality tiles that exceed customer expectations in terms of durability, design, and value. We strive to be environmentally responsible while providing exceptional service and building lasting relationships with our customers and partners.
              </p>
            </div>
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="mb-4">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-primary-50 mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ff7342" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"></path>
                  </svg>
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
              <p className="text-neutral-700">
                To be recognized as the industry leader in tile manufacturing in Gujarat, setting benchmarks for product quality, innovation, and customer satisfaction. We aim to expand our reach across India while maintaining our commitment to ethical business practices and sustainable manufacturing.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section">
        <div className="container-custom">
          <SectionTitle 
            title="Our Values" 
            subtitle="The principles that guide everything we do"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-3">Quality</h3>
              <p className="text-neutral-700">We never compromise on quality, ensuring that every product that leaves our facility meets our rigorous standards.</p>
            </div>
            <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-3">Integrity</h3>
              <p className="text-neutral-700">We conduct our business with honesty, transparency, and ethical practices, building trust with our customers and partners.</p>
            </div>
            <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-3">Innovation</h3>
              <p className="text-neutral-700">We continuously seek to improve our products and processes, embracing new technologies and ideas.</p>
            </div>
            <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-3">Customer Focus</h3>
              <p className="text-neutral-700">We prioritize our customers' needs and satisfaction, providing personalized service and timely support.</p>
            </div>
            <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-3">Sustainability</h3>
              <p className="text-neutral-700">We are committed to environmentally responsible manufacturing practices and resource efficiency.</p>
            </div>
            <div className="border border-neutral-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-300">
              <h3 className="text-xl font-semibold mb-3">Teamwork</h3>
              <p className="text-neutral-700">We value collaboration, respect, and the diverse skills and perspectives of our team members.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="section bg-neutral-50">
        <div className="container-custom">
          <SectionTitle 
            title="Our Facilities" 
            subtitle="State-of-the-art manufacturing facility in Upleta, Gujarat"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-4">Manufacturing Excellence</h3>
              <ul className="space-y-4">
                <li className="flex">
                  <svg className="w-6 h-6 text-primary-500 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">20,000 sq. ft. Production Area</span>
                    <p className="text-neutral-600">Spacious facility equipped with modern machinery</p>
                  </div>
                </li>
                <li className="flex">
                  <svg className="w-6 h-6 text-primary-500 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Advanced Machinery</span>
                    <p className="text-neutral-600">Hydraulic presses, mixers, and quality control equipment</p>
                  </div>
                </li>
                <li className="flex">
                  <svg className="w-6 h-6 text-primary-500 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Quality Control Lab</span>
                    <p className="text-neutral-600">Dedicated testing facilities for ensuring product quality</p>
                  </div>
                </li>
                <li className="flex">
                  <svg className="w-6 h-6 text-primary-500 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Skilled Workforce</span>
                    <p className="text-neutral-600">Experienced team of 50+ skilled workers and technicians</p>
                  </div>
                </li>
                <li className="flex">
                  <svg className="w-6 h-6 text-primary-500 mr-2 flex-shrink-0" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Production Capacity</span>
                    <p className="text-neutral-600">10,000+ sq. ft. of tiles and paver blocks daily</p>
                  </div>
                </li>
              </ul>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Manufacturing Facility"
                className="rounded-lg shadow-md w-full h-48 object-cover"
              />
              <img
                src="https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Quality Testing"
                className="rounded-lg shadow-md w-full h-48 object-cover"
              />
              <img
                src="https://images.pexels.com/photos/5691643/pexels-photo-5691643.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Tile Production"
                className="rounded-lg shadow-md w-full h-48 object-cover"
              />
              <img
                src="https://images.pexels.com/photos/259751/pexels-photo-259751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Warehouse"
                className="rounded-lg shadow-md w-full h-48 object-cover"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
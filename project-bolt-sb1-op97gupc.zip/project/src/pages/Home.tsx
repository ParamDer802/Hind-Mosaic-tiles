import React from 'react';
import Hero from '../components/home/Hero';
import Categories from '../components/home/Categories';
import Features from '../components/home/Features';
import Testimonials from '../components/home/Testimonials';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <Categories />
      <Features />
      
      {/* CTA Section */}
      <section className="relative py-20">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.pexels.com/photos/4846097/pexels-photo-4846097.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            alt="Tiles Pattern"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary-900 bg-opacity-80"></div>
        </div>
        
        <div className="container-custom relative z-10">
          <div className="max-w-3xl mx-auto text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Project?</h2>
            <p className="text-lg mb-8">
              Browse our extensive collection of mosaic tiles, paver blocks, and parking tiles. 
              Contact us for custom orders and bulk pricing.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/products" className="btn bg-white text-primary-600 hover:bg-neutral-100">
                View Products
              </Link>
              <Link to="/contact" className="btn border-2 border-white text-white hover:bg-white hover:text-primary-600 transition-colors duration-300">
                Get in Touch
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Testimonials />
    </>
  );
};

export default Home;
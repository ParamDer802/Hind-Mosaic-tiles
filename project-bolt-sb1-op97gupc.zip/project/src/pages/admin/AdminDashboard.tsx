import React from 'react';
import { Users, Package, Image, MessageSquare } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-primary-50 p-6 rounded-lg">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
              <Package className="text-primary-600" size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold">Products</h3>
              <p className="text-2xl font-bold text-primary-600">24</p>
            </div>
          </div>
        </div>

        <div className="bg-secondary-50 p-6 rounded-lg">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-secondary-100 rounded-full flex items-center justify-center">
              <Image className="text-secondary-600" size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold">Gallery Items</h3>
              <p className="text-2xl font-bold text-secondary-600">12</p>
            </div>
          </div>
        </div>

        <div className="bg-neutral-50 p-6 rounded-lg">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-neutral-100 rounded-full flex items-center justify-center">
              <MessageSquare className="text-neutral-600" size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold">Inquiries</h3>
              <p className="text-2xl font-bold text-neutral-600">8</p>
            </div>
          </div>
        </div>

        <div className="bg-green-50 p-6 rounded-lg">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Users className="text-green-600" size={24} />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-semibold">Visitors</h3>
              <p className="text-2xl font-bold text-green-600">156</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-neutral-50 p-6 rounded-lg">
        <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
        <p className="text-neutral-600">No recent activity to display.</p>
      </div>
    </div>
  );
};

export default AdminDashboard;
import React, { useState, useEffect } from 'react';
import { products } from '../utils/productData';
import SectionTitle from '../components/ui/SectionTitle';

const Calculator: React.FC = () => {
  // Form state
  const [selectedProduct, setSelectedProduct] = useState('');
  const [area, setArea] = useState<number>(100);
  const [includeGST, setIncludeGST] = useState(true);
  
  // Result state
  const [totalPrice, setTotalPrice] = useState<number | null>(null);
  const [pricePerSqFt, setPricePerSqFt] = useState<number | null>(null);

  // Calculate price when inputs change
  useEffect(() => {
    if (selectedProduct && area) {
      const product = products.find(p => p.id === selectedProduct);
      if (product) {
        const price = includeGST ? product.gstPrice : product.price;
        setPricePerSqFt(price);
        setTotalPrice(price * area);
      }
    } else {
      setTotalPrice(null);
      setPricePerSqFt(null);
    }
  }, [selectedProduct, area, includeGST]);

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Calculation is already happening in useEffect
  };

  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 bg-neutral-900">
        <div className="container-custom text-center text-white py-20">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Price Calculator</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Estimate the cost of your project with our easy-to-use calculator
          </p>
        </div>
      </section>

      {/* Calculator Section */}
      <section className="section">
        <div className="container-custom max-w-4xl">
          <SectionTitle 
            title="Project Cost Estimator" 
            subtitle="Select a product, enter your required area, and get an instant cost estimate"
          />

          <div className="bg-white p-8 rounded-lg shadow-md">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Product Selection */}
              <div>
                <label htmlFor="product" className="block text-sm font-medium text-neutral-700 mb-2">
                  Select Product
                </label>
                <select
                  id="product"
                  value={selectedProduct}
                  onChange={(e) => setSelectedProduct(e.target.value)}
                  className="w-full p-3 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                >
                  <option value="">-- Select a product --</option>
                  {products.map((product) => (
                    <option key={product.id} value={product.id}>
                      {product.name} ({product.size})
                    </option>
                  ))}
                </select>
              </div>

              {/* Area Input */}
              <div>
                <label htmlFor="area" className="block text-sm font-medium text-neutral-700 mb-2">
                  Area (in sq. ft.)
                </label>
                <input
                  type="number"
                  id="area"
                  value={area}
                  onChange={(e) => setArea(Number(e.target.value))}
                  min="1"
                  className="w-full p-3 border border-neutral-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  required
                />
              </div>

              {/* GST Option */}
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="gst"
                  checked={includeGST}
                  onChange={(e) => setIncludeGST(e.target.checked)}
                  className="h-5 w-5 text-primary-500 focus:ring-primary-500 border-neutral-300 rounded"
                />
                <label htmlFor="gst" className="ml-2 block text-sm text-neutral-700">
                  Include GST (18%)
                </label>
              </div>

              {/* Calculate Button */}
              <button
                type="submit"
                className="w-full btn-primary py-3"
              >
                Calculate Cost
              </button>
            </form>

            {/* Results */}
            {totalPrice !== null && (
              <div className="mt-8 pt-6 border-t border-neutral-200">
                <h3 className="text-lg font-semibold mb-4">Estimated Cost</h3>
                <div className="bg-neutral-50 p-4 rounded-md">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-neutral-500">Selected Product:</p>
                      <p className="font-medium">
                        {products.find(p => p.id === selectedProduct)?.name}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Area:</p>
                      <p className="font-medium">{area} sq. ft.</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">Price per sq. ft.:</p>
                      <p className="font-medium">₹{pricePerSqFt?.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-500">GST:</p>
                      <p className="font-medium">{includeGST ? 'Included (18%)' : 'Not included'}</p>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-neutral-200">
                    <div className="flex justify-between items-center">
                      <p className="text-lg font-semibold">Total Estimated Cost:</p>
                      <p className="text-xl font-bold text-primary-600">₹{totalPrice.toFixed(2)}</p>
                    </div>
                  </div>
                </div>
                <p className="mt-4 text-sm text-neutral-500">
                  Note: This is an estimated cost. Actual prices may vary based on specific requirements, 
                  customizations, and transportation costs. Please contact us for a detailed quote.
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section bg-neutral-50">
        <div className="container-custom max-w-4xl">
          <SectionTitle 
            title="Frequently Asked Questions" 
            subtitle="Common questions about ordering and pricing"
          />

          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold mb-2">How accurate is this calculator?</h3>
              <p className="text-neutral-600">
                This calculator provides an estimate based on standard pricing. Actual costs may vary 
                based on specific project requirements, delivery location, and quantity discounts.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold mb-2">Do you offer bulk discounts?</h3>
              <p className="text-neutral-600">
                Yes, we offer discounts for bulk orders. Please contact our sales team for custom 
                quotations on large projects.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold mb-2">What additional costs should I consider?</h3>
              <p className="text-neutral-600">
                Additional costs may include transportation, installation labor, adhesives, and other 
                materials needed for installation. We recommend adding 5-10% extra material to account 
                for cuts and breakage.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-lg font-semibold mb-2">How do I place an order?</h3>
              <p className="text-neutral-600">
                After using the calculator, you can contact us through our contact page with your 
                requirements. Our team will get back to you with a detailed quotation and payment options.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Calculator;
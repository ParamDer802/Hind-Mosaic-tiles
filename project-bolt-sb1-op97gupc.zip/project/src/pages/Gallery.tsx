import React, { useState } from 'react';
import SectionTitle from '../components/ui/SectionTitle';
import GalleryImage from '../components/ui/GalleryImage';

// Define gallery item interface
interface GalleryItem {
  id: number;
  src: string;
  alt: string;
  category: 'mosaic' | 'paver' | 'parking' | 'installation';
  categoryName: string;
}

const Gallery: React.FC = () => {
  // Gallery items data
  const galleryItems: GalleryItem[] = [
    {
      id: 1,
      src: 'https://images.pexels.com/photos/5699663/pexels-photo-5699663.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Modern Bathroom with Mosaic Tiles',
      category: 'mosaic',
      categoryName: 'Mosaic Tiles'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/5825599/pexels-photo-5825599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Contemporary Kitchen Flooring',
      category: 'mosaic',
      categoryName: 'Mosaic Tiles'
    },
    {
      id: 3,
      src: 'https://images.pexels.com/photos/5891584/pexels-photo-5891584.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Outdoor Garden Pathway',
      category: 'paver',
      categoryName: 'Paver Blocks'
    },
    {
      id: 4,
      src: 'https://images.pexels.com/photos/6186812/pexels-photo-6186812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Residential Driveway with Pavers',
      category: 'paver',
      categoryName: 'Paver Blocks'
    },
    {
      id: 5,
      src: 'https://images.pexels.com/photos/1191710/pexels-photo-1191710.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Commercial Parking Lot',
      category: 'parking',
      categoryName: 'Parking Tiles'
    },
    {
      id: 6,
      src: 'https://images.pexels.com/photos/3850519/pexels-photo-3850519.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Apartment Complex Parking',
      category: 'parking',
      categoryName: 'Parking Tiles'
    },
    {
      id: 7,
      src: 'https://images.pexels.com/photos/6306387/pexels-photo-6306387.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Tile Installation Process',
      category: 'installation',
      categoryName: 'Installation'
    },
    {
      id: 8,
      src: 'https://images.pexels.com/photos/4491881/pexels-photo-4491881.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Commercial Project Completion',
      category: 'installation',
      categoryName: 'Installation'
    },
    {
      id: 9,
      src: 'https://images.pexels.com/photos/6444557/pexels-photo-6444557.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Decorative Wall Mosaic',
      category: 'mosaic',
      categoryName: 'Mosaic Tiles'
    },
    {
      id: 10,
      src: 'https://images.pexels.com/photos/3846337/pexels-photo-3846337.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Garden Pathway Project',
      category: 'paver',
      categoryName: 'Paver Blocks'
    },
    {
      id: 11,
      src: 'https://images.pexels.com/photos/5825606/pexels-photo-5825606.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Luxury Bathroom Flooring',
      category: 'mosaic',
      categoryName: 'Mosaic Tiles'
    },
    {
      id: 12,
      src: 'https://images.pexels.com/photos/3847458/pexels-photo-3847458.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      alt: 'Public Plaza with Pavers',
      category: 'paver',
      categoryName: 'Paver Blocks'
    }
  ];

  // Filter state
  const [activeFilter, setActiveFilter] = useState<string>('all');

  // Filter categories
  const categories = [
    { id: 'all', name: 'All Projects' },
    { id: 'mosaic', name: 'Mosaic Tiles' },
    { id: 'paver', name: 'Paver Blocks' },
    { id: 'parking', name: 'Parking Tiles' },
    { id: 'installation', name: 'Installation' }
  ];

  // Filter gallery items
  const filteredItems = activeFilter === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === activeFilter);

  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 bg-neutral-900">
        <div className="container-custom text-center text-white py-20">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Gallery</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Explore our completed projects and installations
          </p>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="section">
        <div className="container-custom">
          <SectionTitle 
            title="Our Project Gallery" 
            subtitle="Browse through our portfolio of completed projects and installations"
          />

          {/* Filters */}
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setActiveFilter(category.id)}
                className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeFilter === category.id
                    ? 'bg-primary-500 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map(item => (
              <GalleryImage
                key={item.id}
                src={item.src}
                alt={item.alt}
                category={item.categoryName}
              />
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-neutral-600 mb-4">No images found in this category.</p>
              <button
                onClick={() => setActiveFilter('all')}
                className="btn-primary"
              >
                View All Projects
              </button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="section bg-neutral-100">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Project?</h2>
          <p className="text-lg text-neutral-700 mb-8 max-w-3xl mx-auto">
            Contact us today to discuss how our products can transform your space.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a href="/products" className="btn-primary">
              Explore Products
            </a>
            <a href="/contact" className="btn-outline">
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </>
  );
};

export default Gallery;
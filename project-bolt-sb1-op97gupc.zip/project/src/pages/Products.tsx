import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import SectionTitle from '../components/ui/SectionTitle';
import ProductCard from '../components/ui/ProductCard';
import { getProductsByCategory, products } from '../utils/productData';

const Products: React.FC = () => {
  const location = useLocation();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [filteredProducts, setFilteredProducts] = useState(products);

  // Categories
  const categories = [
    { id: 'mosaic', name: 'Mosaic Tiles' },
    { id: 'paver', name: 'Paver Blocks' },
    { id: 'parking', name: 'Parking Tiles' },
  ];

  // Handle category filter from URL params
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const category = params.get('category');
    setActiveCategory(category);
    setFilteredProducts(getProductsByCategory(category));
  }, [location.search]);

  // Handle category change
  const handleCategoryChange = (categoryId: string | null) => {
    setActiveCategory(categoryId);
    setFilteredProducts(getProductsByCategory(categoryId));
  };

  return (
    <>
      {/* Hero Section */}
      <section className="relative py-20 bg-neutral-900">
        <div className="container-custom text-center text-white py-20">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Products</h1>
          <p className="text-xl max-w-2xl mx-auto">
            Explore our wide range of high-quality mosaic tiles, paver blocks, and parking tiles
          </p>
        </div>
      </section>

      {/* Product Filters */}
      <section className="py-8 bg-neutral-100 sticky top-16 z-30">
        <div className="container-custom">
          <div className="flex flex-wrap items-center">
            <span className="mr-4 font-medium">Filter by:</span>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleCategoryChange(null)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  activeCategory === null
                    ? 'bg-primary-500 text-white'
                    : 'bg-white text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                All Products
              </button>
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => handleCategoryChange(category.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                    activeCategory === category.id
                      ? 'bg-primary-500 text-white'
                      : 'bg-white text-neutral-700 hover:bg-neutral-200'
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="section">
        <div className="container-custom">
          <SectionTitle
            title={activeCategory ? `${categories.find(c => c.id === activeCategory)?.name}` : 'All Products'}
            subtitle="Browse our collection of high-quality products"
          />

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  image={product.image}
                  price={product.price}
                  gstPrice={product.gstPrice}
                  size={product.size}
                  category={product.categoryName}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-lg text-neutral-600 mb-4">No products found in this category.</p>
              <button
                onClick={() => handleCategoryChange(null)}
                className="btn-primary"
              >
                View All Products
              </button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="section bg-neutral-100">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-4">Can't Find What You're Looking For?</h2>
          <p className="text-lg text-neutral-700 mb-8 max-w-3xl mx-auto">
            We offer custom solutions tailored to your specific requirements. Contact us to discuss your project needs.
          </p>
          <Link to="/contact" className="btn-primary">
            Get in Touch
          </Link>
        </div>
      </section>
    </>
  );
};

export default Products;
// Mock data for products
export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  category: 'mosaic' | 'paver' | 'parking';
  categoryName: string;
  price: number;
  gstPrice: number;
  size: string;
  thickness: string;
  material: string;
  applications: string[];
  features: string[];
  colors: string[];
}

export const products: Product[] = [
  {
    id: 'mosaic-classic-1',
    name: 'Classic Mosaic Tile',
    description: 'A timeless classic mosaic tile design perfect for indoor floors and walls. These versatile tiles bring elegance to any space with their traditional patterning.',
    image: 'https://images.pexels.com/photos/5870433/pexels-photo-5870433.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'mosaic',
    categoryName: 'Mosaic Tiles',
    price: 45,
    gstPrice: 53.1,
    size: '1x1 ft',
    thickness: '20 mm',
    material: 'Cement, Sand, Stone Chips',
    applications: ['Indoor Flooring', 'Wall Decoration', 'Bathroom', 'Kitchen'],
    features: ['Anti-Slip', 'Durable', 'Easy to Clean', 'Stain Resistant'],
    colors: ['White', 'Grey', 'Black', 'Red']
  },
  {
    id: 'mosaic-premium-1',
    name: 'Premium Mosaic Tile',
    description: 'Elevate your space with our premium mosaic tiles featuring intricate patterns and superior finish. Ideal for creating statement floors and accent walls.',
    image: 'https://images.pexels.com/photos/5870955/pexels-photo-5870955.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'mosaic',
    categoryName: 'Mosaic Tiles',
    price: 60,
    gstPrice: 70.8,
    size: '1x1 ft',
    thickness: '22 mm',
    material: 'Cement, Fine Sand, Premium Stone Chips',
    applications: ['Indoor Flooring', 'Feature Walls', 'Hotel Lobbies', 'Luxury Residential'],
    features: ['Premium Finish', 'Highly Durable', 'Stain Resistant', 'Water Resistant'],
    colors: ['Beige', 'Maroon', 'Green', 'Blue']
  },
  {
    id: 'paver-zigzag-1',
    name: 'Zigzag Paver Block',
    description: 'Interlocking zigzag paver blocks that create an attractive and highly stable surface for driveways, walkways, and outdoor spaces.',
    image: 'https://images.pexels.com/photos/3254068/pexels-photo-3254068.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'paver',
    categoryName: 'Paver Blocks',
    price: 65,
    gstPrice: 76.7,
    size: '60 mm thickness',
    thickness: '60 mm',
    material: 'Cement, Sand, Stone Aggregates',
    applications: ['Driveways', 'Walkways', 'Gardens', 'Public Spaces'],
    features: ['Interlocking Design', 'High Strength', 'Weather Resistant', 'Easy Installation'],
    colors: ['Red', 'Grey', 'Black']
  },
  {
    id: 'paver-hexagon-1',
    name: 'Hexagonal Paver Block',
    description: 'Stylish hexagonal paver blocks that create a honeycomb pattern, perfect for contemporary outdoor designs and commercial spaces.',
    image: 'https://images.pexels.com/photos/6031034/pexels-photo-6031034.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'paver',
    categoryName: 'Paver Blocks',
    price: 70,
    gstPrice: 82.6,
    size: '75 mm thickness',
    thickness: '75 mm',
    material: 'High-strength Cement, Graded Aggregates',
    applications: ['Commercial Spaces', 'Parks', 'Residential Driveways', 'Plazas'],
    features: ['Modern Design', 'High Compressive Strength', 'Low Water Absorption', 'Frost Resistant'],
    colors: ['Grey', 'Terracotta', 'Brown', 'Sandstone']
  },
  {
    id: 'parking-standard-1',
    name: 'Standard Parking Tile',
    description: 'Durable parking tiles designed specifically for vehicle traffic with excellent load-bearing capacity and skid resistance.',
    image: 'https://images.pexels.com/photos/1191710/pexels-photo-1191710.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'parking',
    categoryName: 'Parking Tiles',
    price: 55,
    gstPrice: 64.9,
    size: '1x1 ft',
    thickness: '25 mm',
    material: 'Heavy-duty Cement, Coarse Aggregates',
    applications: ['Residential Parking', 'Light Vehicle Areas', 'Walkways', 'Courtyards'],
    features: ['Anti-Skid Surface', 'Durable', 'Easy Maintenance', 'Weather Resistant'],
    colors: ['Grey', 'Red']
  },
  {
    id: 'parking-heavy-1',
    name: 'Heavy-Duty Parking Tile',
    description: 'Extra-strength parking tiles designed for commercial parking lots and areas with heavy vehicle traffic, featuring enhanced durability and wear resistance.',
    image: 'https://images.pexels.com/photos/3850519/pexels-photo-3850519.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'parking',
    categoryName: 'Parking Tiles',
    price: 75,
    gstPrice: 88.5,
    size: '2x2 ft',
    thickness: '35 mm',
    material: 'High-strength Cement, Special Aggregates, Reinforcement',
    applications: ['Commercial Parking', 'Heavy Vehicle Areas', 'Industrial Spaces', 'Loading Zones'],
    features: ['Superior Load Capacity', 'High Abrasion Resistance', 'Chemical Resistant', 'Enhanced Anti-Skid'],
    colors: ['Grey', 'Black', 'Yellow']
  },
  {
    id: 'mosaic-designer-1',
    name: 'Designer Mosaic Tile',
    description: 'Artistically crafted designer mosaic tiles that serve as the centerpiece of any room, featuring unique patterns and color combinations.',
    image: 'https://images.pexels.com/photos/5699665/pexels-photo-5699665.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'mosaic',
    categoryName: 'Mosaic Tiles',
    price: 85,
    gstPrice: 100.3,
    size: '2x2 ft',
    thickness: '22 mm',
    material: 'Premium Cement, Special Aggregates, Colored Pigments',
    applications: ['Feature Floors', 'Accent Walls', 'Luxury Bathrooms', 'Hotel Lobbies'],
    features: ['Artistic Designs', 'Premium Finish', 'Custom Color Options', 'High Durability'],
    colors: ['Multi-color', 'Blue-White', 'Earth Tones', 'Custom']
  },
  {
    id: 'paver-square-1',
    name: 'Square Paver Block',
    description: 'Classic square paver blocks that create a clean, structured look for walkways, patios, and outdoor spaces.',
    image: 'https://images.pexels.com/photos/4488638/pexels-photo-4488638.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'paver',
    categoryName: 'Paver Blocks',
    price: 58,
    gstPrice: 68.44,
    size: '50 mm thickness',
    thickness: '50 mm',
    material: 'Cement, Sand, Stone Aggregates',
    applications: ['Walkways', 'Garden Paths', 'Patios', 'Pool Surrounds'],
    features: ['Clean Design', 'Easy Installation', 'Durable', 'Low Maintenance'],
    colors: ['Grey', 'Red', 'Yellow', 'Black']
  },
];

// Function to get products by category
export const getProductsByCategory = (category: string | null): Product[] => {
  if (!category) return products;
  return products.filter(product => product.category === category);
};

// Function to get product by ID
export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

// Function to get featured products (for homepage)
export const getFeaturedProducts = (): Product[] => {
  return products.slice(0, 3);
};
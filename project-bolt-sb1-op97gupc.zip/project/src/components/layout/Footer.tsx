import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Youtube, MapPin, Phone, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { name: 'Home', path: '/' },
    { name: 'About Us', path: '/about' },
    { name: 'Products', path: '/products' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Calculator', path: '/calculator' },
    { name: 'Contact', path: '/contact' },
  ];

  const productCategories = [
    { name: 'Mosaic Tiles', path: '/products?category=mosaic' },
    { name: 'Paver Blocks', path: '/products?category=paver' },
    { name: 'Parking Tiles', path: '/products?category=parking' },
  ];

  return (
    <footer className="bg-neutral-900 text-white pt-16 pb-8">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="grid grid-cols-2 gap-1">
                <div className="w-3 h-3 bg-primary-500 rounded-sm"></div>
                <div className="w-3 h-3 bg-primary-600 rounded-sm"></div>
                <div className="w-3 h-3 bg-primary-700 rounded-sm"></div>
                <div className="w-3 h-3 bg-primary-800 rounded-sm"></div>
              </div>
              <span className="text-xl font-bold">Hind Mosaic Tiles</span>
            </div>
            <p className="text-neutral-300 mb-6">
              Quality assured mosaic tiles, paver blocks, and parking tiles from Upleta, Gujarat.
            </p>
            <div className="flex items-center space-x-4">
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-500 transition-colors duration-200"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-500 transition-colors duration-200"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a 
                href="https://youtube.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-white hover:text-primary-500 transition-colors duration-200"
                aria-label="YouTube"
              >
                <Youtube size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.path}
                    className="text-neutral-300 hover:text-primary-500 transition-colors duration-200"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Products</h4>
            <ul className="space-y-3">
              {productCategories.map((category) => (
                <li key={category.name}>
                  <Link 
                    to={category.path}
                    className="text-neutral-300 hover:text-primary-500 transition-colors duration-200"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex">
                <MapPin size={20} className="mr-3 text-primary-500 flex-shrink-0 mt-1" />
                <span className="text-neutral-300">Upleta, Gujarat, India</span>
              </li>
              <li className="flex">
                <Phone size={20} className="mr-3 text-primary-500 flex-shrink-0" />
                <a 
                  href="tel:+919876543210" 
                  className="text-neutral-300 hover:text-primary-500 transition-colors duration-200"
                >
                  +91-9876543210
                </a>
              </li>
              <li className="flex">
                <Mail size={20} className="mr-3 text-primary-500 flex-shrink-0" />
                <a 
                  href="mailto:hindmosaictiles@gmail.com" 
                  className="text-neutral-300 hover:text-primary-500 transition-colors duration-200"
                >
                  hindmosaictiles@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 border-t border-neutral-800 text-center text-neutral-400 text-sm">
          <p>© {currentYear} Hind Mosaic Tiles. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
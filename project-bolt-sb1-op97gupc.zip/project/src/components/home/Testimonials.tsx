import React from 'react';
import SectionTitle from '../ui/SectionTitle';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      id: 1,
      name: 'Rajesh Patel',
      role: 'Property Developer',
      content: 'We\'ve been using Hind Mosaic Tiles for our residential projects for over 3 years. Their products are consistently high quality and they always deliver on time.',
      image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 2,
      name: 'Sneha Sharma',
      role: 'Interior Designer',
      content: 'The variety of designs and color options that Hind Mosaic offers has helped me create unique spaces for my clients. The quality is excellent and they are a pleasure to work with.',
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
    {
      id: 3,
      name: 'Amit Verma',
      role: 'Contractor',
      content: 'The paver blocks we purchased have exceptional durability. Even after two years of heavy use in a commercial space, they look as good as new. Highly recommended!',
      image: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    },
  ];

  return (
    <section className="section bg-secondary-50">
      <div className="container-custom">
        <SectionTitle 
          title="What Our Clients Say" 
          subtitle="Don't just take our word for it - hear from our satisfied customers"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-md relative">
              <div className="absolute -top-5 left-6">
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M14.4 24H8.4C7.2 24 6 25.2 6 26.4V33.6C6 34.8 7.2 36 8.4 36H14.4C15.6 36 16.8 34.8 16.8 33.6V26.4C16.8 25.2 15.6 24 14.4 24ZM14.4 33.6H8.4V26.4H14.4V33.6ZM12 12C9.6 12 7.2 14.4 7.2 16.8C7.2 19.2 9.6 21.6 12 21.6C14.4 21.6 16.8 19.2 16.8 16.8C16.8 14.4 14.4 12 12 12ZM12 19.2C10.8 19.2 9.6 18 9.6 16.8C9.6 15.6 10.8 14.4 12 14.4C13.2 14.4 14.4 15.6 14.4 16.8C14.4 18 13.2 19.2 12 19.2ZM27.6 24H21.6C20.4 24 19.2 25.2 19.2 26.4V33.6C19.2 34.8 20.4 36 21.6 36H27.6C28.8 36 30 34.8 30 33.6V26.4C30 25.2 28.8 24 27.6 24ZM27.6 33.6H21.6V26.4H27.6V33.6ZM25.2 12C22.8 12 20.4 14.4 20.4 16.8C20.4 19.2 22.8 21.6 25.2 21.6C27.6 21.6 30 19.2 30 16.8C30 14.4 27.6 12 25.2 12ZM25.2 19.2C24 19.2 22.8 18 22.8 16.8C22.8 15.6 24 14.4 25.2 14.4C26.4 14.4 27.6 15.6 27.6 16.8C27.6 18 26.4 19.2 25.2 19.2ZM40.8 24H34.8C33.6 24 32.4 25.2 32.4 26.4V33.6C32.4 34.8 33.6 36 34.8 36H40.8C42 36 43.2 34.8 43.2 33.6V26.4C43.2 25.2 42 24 40.8 24ZM40.8 33.6H34.8V26.4H40.8V33.6ZM38.4 12C36 12 33.6 14.4 33.6 16.8C33.6 19.2 36 21.6 38.4 21.6C40.8 21.6 43.2 19.2 43.2 16.8C43.2 14.4 40.8 12 38.4 12ZM38.4 19.2C37.2 19.2 36 18 36 16.8C36 15.6 37.2 14.4 38.4 14.4C39.6 14.4 40.8 15.6 40.8 16.8C40.8 18 39.6 19.2 38.4 19.2Z" fill="#FF7342" fillOpacity="0.2"/>
                </svg>
              </div>
              <div className="pt-8">
                <p className="text-neutral-700 mb-6">{testimonial.content}</p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-sm text-neutral-500">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
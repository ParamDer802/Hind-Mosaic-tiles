import React from 'react';
import { Shield, Truck, Award, Ruler } from 'lucide-react';
import SectionTitle from '../ui/SectionTitle';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Shield size={36} className="text-primary-500" />,
      title: 'Quality Assured',
      description: 'All our products undergo rigorous quality checks to ensure durability and longevity.',
    },
    {
      icon: <Truck size={36} className="text-primary-500" />,
      title: 'Nationwide Delivery',
      description: 'We deliver our products across India with careful packaging to ensure safe transport.',
    },
    {
      icon: <Award size={36} className="text-primary-500" />,
      title: 'Industry Experience',
      description: 'With years of expertise, we understand the market needs and deliver accordingly.',
    },
    {
      icon: <Ruler size={36} className="text-primary-500" />,
      title: 'Custom Solutions',
      description: 'We offer customized solutions tailored to meet specific project requirements.',
    },
  ];

  return (
    <section className="section">
      <div className="container-custom">
        <SectionTitle 
          title="Why Choose Us" 
          subtitle="We are committed to delivering premium quality products and exceptional service"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="text-center p-6 border border-neutral-200 rounded-lg hover:shadow-md transition-shadow duration-300"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary-50 mb-4">
                {feature.icon}
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-neutral-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
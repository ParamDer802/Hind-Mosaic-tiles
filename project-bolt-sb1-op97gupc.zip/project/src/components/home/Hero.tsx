import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.pexels.com/photos/6782503/pexels-photo-6782503.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
          alt="Tiles Installation"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-60"></div>
      </div>

      {/* Content */}
      <div className="container-custom relative z-10 text-white pt-20">
        <div className="max-w-3xl animate-fade-in">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
            Bringing Designs to Life – Hind Mosaic Tiles
          </h1>
          <p className="text-lg md:text-xl mb-8 text-neutral-200">
            Premium quality mosaic tiles, paver blocks, and parking tiles from Gujarat's trusted manufacturer. Combining traditional craftsmanship with modern design.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link to="/products" className="btn-primary">
              Explore Our Collection
              <ArrowRight size={18} className="ml-2" />
            </Link>
            <Link to="/contact" className="btn bg-white text-neutral-900 hover:bg-neutral-100 focus:ring-white">
              Contact Us
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
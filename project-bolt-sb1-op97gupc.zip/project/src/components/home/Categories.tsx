import React from 'react';
import { Link } from 'react-router-dom';
import SectionTitle from '../ui/SectionTitle';

const Categories: React.FC = () => {
  const categories = [
    {
      id: 'mosaic',
      name: 'Mosaic Tiles',
      description: 'Versatile and decorative tiles for walls and floors, perfect for creating custom patterns.',
      image: 'https://images.pexels.com/photos/5873742/pexels-photo-5873742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'paver',
      name: 'Paver Blocks',
      description: 'Durable interlocking blocks ideal for walkways, driveways, and landscape design.',
      image: 'https://images.pexels.com/photos/5871217/pexels-photo-5871217.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    },
    {
      id: 'parking',
      name: 'Parking Tiles',
      description: 'Heavy-duty tiles designed to withstand vehicle traffic with anti-skid properties.',
      image: 'https://images.pexels.com/photos/5691622/pexels-photo-5691622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    }
  ];

  return (
    <section className="section bg-neutral-50">
      <div className="container-custom">
        <SectionTitle
          title="Our Product Categories"
          subtitle="We provide high-quality tiles and paver blocks for all your construction and design needs"
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {categories.map((category) => (
            <div key={category.id} className="card group animate-slide-up">
              <div className="relative overflow-hidden h-64">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 group-hover:bg-opacity-30 transition-all duration-300"></div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{category.name}</h3>
                <p className="text-neutral-600 mb-4">{category.description}</p>
                <Link
                  to={`/products?category=${category.id}`}
                  className="text-primary-500 font-medium inline-flex items-center hover:text-primary-600 transition-colors duration-200"
                >
                  View Products
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="ml-1"
                  >
                    <path d="m9 18 6-6-6-6" />
                  </svg>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;
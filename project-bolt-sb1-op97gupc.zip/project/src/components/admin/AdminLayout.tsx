import React from 'react';
import { Outlet, Link, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Box, Image, MessageSquare, LogOut } from 'lucide-react';
import { supabase } from '../../utils/supabaseClient';

const AdminLayout: React.FC = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/admin/login');
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Admin Header */}
      <header className="bg-white shadow-sm">
        <div className="container-custom py-4 flex items-center justify-between">
          <Link to="/admin" className="text-xl font-bold text-primary-600">
            Admin Panel
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center text-neutral-600 hover:text-primary-600"
          >
            <LogOut size={18} className="mr-2" />
            Logout
          </button>
        </div>
      </header>

      <div className="container-custom py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Sidebar */}
          <aside className="col-span-12 md:col-span-3 lg:col-span-2">
            <nav className="bg-white rounded-lg shadow-sm p-4">
              <ul className="space-y-2">
                <li>
                  <Link
                    to="/admin"
                    className="flex items-center p-2 text-neutral-600 hover:text-primary-600 hover:bg-neutral-50 rounded-md"
                  >
                    <LayoutDashboard size={18} className="mr-2" />
                    Dashboard
                  </Link>
                </li>
                <li>
                  <Link
                    to="/admin/products"
                    className="flex items-center p-2 text-neutral-600 hover:text-primary-600 hover:bg-neutral-50 rounded-md"
                  >
                    <Box size={18} className="mr-2" />
                    Products
                  </Link>
                </li>
                <li>
                  <Link
                    to="/admin/gallery"
                    className="flex items-center p-2 text-neutral-600 hover:text-primary-600 hover:bg-neutral-50 rounded-md"
                  >
                    <Image size={18} className="mr-2" />
                    Gallery
                  </Link>
                </li>
                <li>
                  <Link
                    to="/admin/inquiries"
                    className="flex items-center p-2 text-neutral-600 hover:text-primary-600 hover:bg-neutral-50 rounded-md"
                  >
                    <MessageSquare size={18} className="mr-2" />
                    Inquiries
                  </Link>
                </li>
              </ul>
            </nav>
          </aside>

          {/* Main Content */}
          <main className="col-span-12 md:col-span-9 lg:col-span-10">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <Outlet />
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
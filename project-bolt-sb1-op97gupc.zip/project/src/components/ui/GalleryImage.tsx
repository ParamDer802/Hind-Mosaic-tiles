import React, { useState } from 'react';

interface GalleryImageProps {
  src: string;
  alt: string;
  category: string;
}

const GalleryImage: React.FC<GalleryImageProps> = ({ src, alt, category }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <div 
        className="relative overflow-hidden rounded-lg cursor-pointer group"
        onClick={() => setIsOpen(true)}
      >
        <img 
          src={src} 
          alt={alt} 
          className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <span className="text-white font-medium text-lg">View</span>
        </div>
        <div className="absolute bottom-4 left-4 bg-white text-neutral-800 text-xs font-semibold px-3 py-1 rounded-full">
          {category}
        </div>
      </div>

      {isOpen && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-90"
          onClick={() => setIsOpen(false)}
        >
          <div 
            className="max-w-4xl w-full p-4 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <img 
              src={src} 
              alt={alt} 
              className="w-full max-h-[85vh] object-contain"
            />
            <button
              className="absolute top-4 right-4 bg-white text-neutral-800 rounded-full w-10 h-10 flex items-center justify-center"
              onClick={() => setIsOpen(false)}
              aria-label="Close"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
            <div className="absolute bottom-4 left-4 bg-white text-neutral-800 text-sm font-medium px-3 py-1 rounded">
              {alt}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GalleryImage;
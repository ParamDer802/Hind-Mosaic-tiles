import React from 'react';
import { Link } from 'react-router-dom';

interface ProductCardProps {
  id: string;
  name: string;
  image: string;
  price: number;
  gstPrice: number;
  size: string;
  category: string;
}

const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  image,
  price,
  gstPrice,
  size,
  category,
}) => {
  return (
    <div className="card group">
      <div className="relative overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute top-4 right-4 bg-primary-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
          {category}
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        <div className="flex items-center text-sm text-neutral-600 mb-4">
          <span className="mr-3">{size}</span>
        </div>
        <div className="flex flex-col space-y-2 mb-6">
          <div className="flex justify-between">
            <span className="text-neutral-600">Base Price:</span>
            <span className="font-medium">₹{price}/sq.ft</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-600">Price (incl. GST):</span>
            <span className="font-semibold text-primary-600">₹{gstPrice}/sq.ft</span>
          </div>
        </div>
        <div className="flex space-x-3">
          <Link
            to={`/products/${id}`}
            className="flex-1 btn-outline text-center text-sm"
          >
            View Details
          </Link>
          <Link
            to={`/contact?product=${id}`}
            className="flex-1 btn-primary text-center text-sm"
          >
            Enquire Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;